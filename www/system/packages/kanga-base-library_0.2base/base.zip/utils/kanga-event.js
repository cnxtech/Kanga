/**
 * 
 */
exports.generateTimeTickEvent = function() {
	var tickString = '{"root":{"_header_":{"log":"","name":"time tick","type":2,"timestamp":1455863028},"tick":{}}}';
	var tickEvent = JSON.parse(tickString);
	tickEvent.root._header_.timestamp = new Date().getTime();
	return tickEvent;
};


