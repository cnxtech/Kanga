function extend(subClass, superClass) {
    var F = function () {};
    F.prototype = superClass.prototype;
//    console.log("F=");
//    console.log(F);
    subClass.prototype = new F();
//    console.log("subClass1=");
//    console.log(subClass);
    subClass.prototype.constructor = subClass;
//    console.log("subClass2=");
//    console.log(subClass);

    subClass._prototype = superClass.prototype;
//    console.log("subClass3=");
//    console.log(subClass);

    if (superClass.prototype.constructor == Object.prototype.constructor) {
        superClass.prototype.constructor = superClass;
    }
//    console.log("subClass4=");
//    console.log(subClass);
}

function clone(obj) {
    if (typeof obj == 'object') {
        var newObj = {};
        for (var attr in obj) {
            newObj[attr] = clone(obj[attr]);
        }
        return newObj;
    } else {
        return obj;
    }
}

Function.prototype.method = function (methodName, fn) {
    this.prototype[methodName] = fn;
    return this;
};

exports.extend = extend;
exports.clone = clone;