var KANGA_EVENT_TYPE = {
    DATA: 0,
    COLLECTION: 1,
    TIME_TICK: 2,
    EOF: 3,
    SYSTEM_LOG: 4,
    NONE: 99
};
module.exports = KANGA_EVENT_TYPE;