var kangaBaseNode = require('../common/kanga-base-node');
var extend = require('../../utils/kanga-common').extend;
var xml2js = require('xml2js');
var KANGA_EVENT = require('../../constants/kanga-event-type');

// for TAS
var sh_adn = require('./thyme/adn');

var usecbhost = '10.240.245.124';
var usecbport = '7590';
var usecbname = 'IoT_Lab';

var useappid = '0.2.481.1.0001.001.00000000000001';
var useappname = 'iyahn';
//var useappport = 9726;
global.useappprotocol = 'xml';
//var usectname = [];
//var usesubname = [];


global.useaeid = '';
global.sh_state = 'crtae';
var return_count = 0;
var request_count = 0;

function ToMobius(params) {
    kangaBaseNode.call(this, params);
    var configFilePath = params.config_file_path;
    this.keyFieldName = params.key_field_name;
    this.valueFieldName = params.value_field_name;
    this.sleepingTime = Number(params.sleeping_time);

    
    this.klogger.debug('configFilePath : ' + configFilePath);
    var data = require('fs').readFileSync(configFilePath, 'utf-8');
    this.klogger.debug(data);

    var parser = new xml2js.Parser({explicitArray: false});
    var self = this;
    this.timer = null;
    parser.parseString(data, function (err, result) {
        if (err) {
            self.klogger.error('ToMobius Parsing An error occurred trying to read in the file: ' + err);
            self.klogger.error('"error : set to default for configuration');
        } else {
            var jsonString = JSON.stringify(result);
            var conf = JSON.parse(jsonString)['m2m:conf'];

            usecbhost = conf.cse['cbhost'];
            usecbport = conf.cse['cbport'];
            usecbname = conf.cse['cbname'];

            useappid = conf.ae['appid'];
            useappname = conf.ae['appname'];
            useappport = conf.ae['appport'];
            useappprotocol = conf.ae['appprotocol'];
            usetasport = conf.ae.tasport;

            if (conf.cnt != null) {
                if (conf.cnt['ctname'] != null) {
                    usectname[0] = conf.cnt;
                } else {
                    usectname = conf.cnt;
                }
            }
            //console.log(usectname);
        }
        self.timer = setInterval(function () {
            manageState();
        }, self.sleepingTime);
    });
}

extend(ToMobius, kangaBaseNode);

ToMobius.prototype._execute = function () {
    switch (this.eventType) {
        case KANGA_EVENT.DATA:
            sendToMobius.call(this);
            break;
        case KANGA_EVENT.COLLECTION:
            break;
        case KANGA_EVENT.TIME_TICK:
            break;
        case KANGA_EVENT.EOF:
            break;
        case KANGA_EVENT.SYSTEM_LOG:
            break;
        default:
            break;
    }
    return null;
}

module.exports = ToMobius;

//ToMobius.prototype.sendToMobius = function() {
function sendToMobius() {
    this.klogger.debug('sendToMobius : ' + JSON.stringify(this.message));
    console.log(usectname);
    if (sh_state == 'crtci') {
        if (this.timer != null) {
            clearInterval(this.timer);
            this.timer = null;
        }
        for (var j = 0; j < usectname.length; j++) {
            var ctname = this.message[this.keyFieldName];
            var content = this.message[this.valueFieldName];
            var self = this;
            if (usectname[j].ctname == ctname) {
                sh_adn.crtci(usecbhost, usecbport, usecbname, useappid, useappname, ctname, content, function (status, ctname) {
                    self.klogger.debug('sendToMobius status: ' + status);
//                    if (status == 5106 || status == 2001 || status == 4015) {
//                        //socket.write('{\"ctname\":\"' + ctname + '\",\"con\":\"' + status + '\"}');
//                    } else if (status == 5000) {
//                        sh_state = 'crtae';
//                        //socket.write('{\"ctname\":\"' + ctname + '\",\"con\":\"' + status + '\"}');
//                    } else {
//                        //socket.write('{\"ctname\":\"' + ctname + '\",\"con\":\"' + status + '\"}');
//                    }
                    if (status == 5000) {
                        sh_state = 'crtae';
                        if (self.timer == null) {
                            self.timer = setInterval(function () {
                                manageState();
                            }, self.sleepingTime);
                        }
                    }
                });
                break;
            }
        }
    }
}

function manageState() {
    console.log('manageState() [sh_state] : ' + sh_state);

    switch (sh_state) {
        case 'crtae':
            sh_adn.crtae(usecbhost, usecbport, usecbname, useappid, useappname, function (status) {
                console.log(sh_state + ' status ' + status);
                if (status == 5106 || status == 2001 || status == 4015 || status == 4105) {
                    sh_state = 'crtct';
                }
            });
            break;
        case 'crtct':
            request_count = 0;
            return_count = 0;
            for (var i = 0; i < usectname.length; i++) {
                request_count++;
                sh_adn.crtct(usecbhost, usecbport, usecbname, useappid, useappname, usectname[i]['ctname'], function (status) {
                    console.log(sh_state + ' status ' + status);
                    if (status == 5106 || status == 2001 || status == 4015 || status == 4105) {
                        return_count++;
                        if (return_count == request_count) {
                            sh_state = 'delsub';
                        }
                    }
                });
            }
            break;
        case 'delsub':
            request_count = 0;
            return_count = 0;
            for (i = 0; i < usectname.length; i++) {
                if (usectname[i]['subname'] != null) {
                    request_count++;
                    sh_adn.delsub(usecbhost, usecbport, usecbname, useappid, useappname, usectname[i]['ctname'], usectname[i]['subname'], usectname[i]['nu'], function (status) {
                        console.log(sh_state + ' status ' + status);
                        if (status == 5106 || status == 2002 || status == 2000 || status == 4015 || status == 4105 || status == 4004) {
                            return_count++;
                            if (return_count == request_count) {
                                sh_state = 'crtsub';
                            }
                        }
                    });
                }
            }

            if (request_count == 0) {
                sh_state = 'crtsub';
            }
            break;
        case 'crtsub':
            request_count = 0;
            return_count = 0;
            for (i = 0; i < usectname.length; i++) {
                if (usectname[i]['subname'] != null) {
                    request_count++;
                    sh_adn.crtsub(usecbhost, usecbport, usecbname, useappid, useappname, usectname[i]['ctname'], usectname[i]['subname'], usectname[i]['nu'], function (status) {
                        console.log(sh_state + ' status ' + status);
                        if (status == 5106 || status == 2001 || status == 4015 || status == 4105) {
                            return_count++;
                            if (return_count == request_count) {
                                sh_state = 'crtci';
                            }
                        }
                    });
                }
            }

            if (request_count == 0) {
                sh_state = 'crtci';
            }
            break;
        case 'crtsub':
            break;
        default:
            break;
    }
}
