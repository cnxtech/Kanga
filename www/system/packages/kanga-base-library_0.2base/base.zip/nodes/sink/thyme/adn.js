/**
 * Created by ryeubi on 2015-08-31.
 */

var http = require('http');
var js2xmlparser = require("js2xmlparser");

var requestid = '';

exports.crtae = function (cbhost, cbport, cbname, appid, appname, callback) {
    var cur_d = new Date();
    var cur_o = cur_d.getTimezoneOffset() / (-60);
    cur_d.setHours(cur_d.getHours() + cur_o);
    var msec = '';
    if ((parseInt(cur_d.getMilliseconds(), 10) < 10)) {
        msec = ('00' + cur_d.getMilliseconds());
    } else if ((parseInt(cur_d.getMilliseconds(), 10) < 100)) {
        msec = ('0' + cur_d.getMilliseconds());
    } else {
        msec = cur_d.getMilliseconds();
    }
    requestid = 'RI' + cur_d.toISOString().replace(/-/, '').replace(/-/, '').replace(/T/, '').replace(/:/, '').replace(/:/, '').replace(/\..+/, '') + msec;

    var results_ae = {};

    var xmlString = '';
    if (useappprotocol == 'xml') {
        results_ae.api = appid;
        results_ae['@'] = {
            "xmlns:m2m": "http://www.onem2m.org/xml/protocols",
            "xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance"
        };

        xmlString = js2xmlparser("m2m:ae", results_ae);
    } else {
        results_ae['m2m:ae'] = {};
        results_ae['m2m:ae'].api = appid;
        xmlString = JSON.stringify(results_ae);
    }

    var path = '/' + cbname;
    var options = {
        hostname: cbhost,
        port: cbport,
        path: path,
        method: 'post',
        headers: {
            'locale': 'ko',
            'X-M2M-RI': requestid,
            'Accept': 'application/xml',
            'X-M2M-Origin': appid,
            'X-M2M-NM': appname,
            'Content-Type': 'application/vnd.onem2m-res+xml; ty=2',
            'Content-Length': xmlString.length
        }
    };

    var req = http.request(options, function (res) {
        console.log('[crtae response : ' + res.statusCode);

        res.setEncoding('utf8');

        res.on('data', function (chunk) {
            console.log(chunk);
            //if(res.headers['x-m2m-rsc'] == 5106 || res.headers['x-m2m-rsc'] == 2001 || res.headers['x-m2m-rsc'] == 4015 || res.headers['x-m2m-rsc'] == 4105) {
            //    sh_state = 'rtvae';
            //}
            //
            //if(sh_state == 'crtae2') {
            //    sh_state = 'crtct';
            //}
            callback(res.headers['x-m2m-rsc']);
        });
    });

    req.on('error', function (e) {
        if (e.message != 'read ECONNRESET') {
            console.log('problem with request: ' + e.message);
        }
    });

    console.log(xmlString);
    req.write(xmlString);
    req.end();
};

exports.rtvae = function (cbhost, cbport, cbname, appid, appname) {
    var cur_d = new Date();
    var cur_o = cur_d.getTimezoneOffset() / (-60);
    cur_d.setHours(cur_d.getHours() + cur_o);
    var msec = '';
    if ((parseInt(cur_d.getMilliseconds(), 10) < 10)) {
        msec = ('00' + cur_d.getMilliseconds());
    } else if ((parseInt(cur_d.getMilliseconds(), 10) < 100)) {
        msec = ('0' + cur_d.getMilliseconds());
    } else {
        msec = cur_d.getMilliseconds();
    }
    requestid = 'RI' + cur_d.toISOString().replace(/-/, '').replace(/-/, '').replace(/T/, '').replace(/:/, '').replace(/:/, '').replace(/\..+/, '') + msec;

    var path = '/' + cbname + '/' + appname;
    var options = {
        hostname: cbhost,
        port: cbport,
        path: path,
        method: 'get',
        headers: {
            'locale': 'ko',
            'X-M2M-RI': requestid,
            'Accept': 'application/xml',
            'X-M2M-Origin': appid,
            'Content-Type': 'application/vnd.onem2m-res+xml'
        }
    };

    var xmlString = '';

    var req = http.request(options, function (res) {
        console.log('[rtvae response] : ' + res.statusCode);

        res.setEncoding('utf8');

        res.on('data', function (chunk) {
            console.log(chunk);
            if (res.headers['x-m2m-rsc'] == 5106 || res.headers['x-m2m-rsc'] == 2000 || res.headers['x-m2m-rsc'] == 4015) {
                sh_state = 'uptae';
            }
        });
    });

    req.on('error', function (e) {
        if (e.message != 'read ECONNRESET') {
            console.log('problem with request: ' + e.message);
        }
    });

    req.write(xmlString);
    req.end();
};


exports.udtae = function (cbhost, cbport, cbname, appid, appname) {
    var cur_d = new Date();
    var cur_o = cur_d.getTimezoneOffset() / (-60);
    cur_d.setHours(cur_d.getHours() + cur_o);
    var msec = '';
    if ((parseInt(cur_d.getMilliseconds(), 10) < 10)) {
        msec = ('00' + cur_d.getMilliseconds());
    } else if ((parseInt(cur_d.getMilliseconds(), 10) < 100)) {
        msec = ('0' + cur_d.getMilliseconds());
    } else {
        msec = cur_d.getMilliseconds();
    }
    requestid = 'RI' + cur_d.toISOString().replace(/-/, '').replace(/-/, '').replace(/T/, '').replace(/:/, '').replace(/:/, '').replace(/\..+/, '') + msec;

    var path = '/' + cbname + '/' + appname;
    var options = {
        hostname: cbhost,
        port: cbport,
        path: path,
        method: 'put',
        headers: {
            'locale': 'ko',
            'X-M2M-RI': requestid,
            'Accept': 'application/xml',
            'X-M2M-Origin': appid,
            'Content-Type': 'application/vnd.onem2m-res+xml'
        }
    };

    var xmlString = '';
    if (useappprotocol == 'xml') {
        results_ae.lbl = 'seahorse';
        results_ae['@'] = {
            "xmlns:m2m": "http://www.onem2m.org/xml/protocols",
            "xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance"
        };

        xmlString = js2xmlparser("m2m:ae", results_ae);
    } else {
        results_ae['m2m:ae'] = {};
        results_ae['m2m:ae'].lbl = 'seahorse';
        xmlString = JSON.stringify(results_ae);
    }

    var req = http.request(options, function (res) {
        console.log('[uptae response : ' + res.statusCode);

        res.setEncoding('utf8');

        res.on('data', function (chunk) {
            console.log(chunk);
            if (res.headers['x-m2m-rsc'] == 5106 || res.headers['x-m2m-rsc'] == 2001 || res.headers['x-m2m-rsc'] == 4015) {
                sh_state = 'delae';
            }
        });
    });

    req.on('error', function (e) {
        if (e.message != 'read ECONNRESET') {
            console.log('problem with request: ' + e.message);
        }
    });

    console.log(xmlString);
    req.write(xmlString);
    req.end();
};


exports.delae = function (cbhost, cbport, cbname, appid, appname) {
    var cur_d = new Date();
    var cur_o = cur_d.getTimezoneOffset() / (-60);
    cur_d.setHours(cur_d.getHours() + cur_o);
    var msec = '';
    if ((parseInt(cur_d.getMilliseconds(), 10) < 10)) {
        msec = ('00' + cur_d.getMilliseconds());
    } else if ((parseInt(cur_d.getMilliseconds(), 10) < 100)) {
        msec = ('0' + cur_d.getMilliseconds());
    } else {
        msec = cur_d.getMilliseconds();
    }
    requestid = 'RI' + cur_d.toISOString().replace(/-/, '').replace(/-/, '').replace(/T/, '').replace(/:/, '').replace(/:/, '').replace(/\..+/, '') + msec;

    var path = '/' + cbname + '/' + appname;
    var options = {
        hostname: cbhost,
        port: cbport,
        path: path,
        method: 'delete',
        headers: {
            'locale': 'ko',
            'X-M2M-RI': requestid,
            'Accept': 'application/xml',
            'X-M2M-Origin': appid,
            'Content-Type': 'application/vnd.onem2m-res+xml'
        }
    };

    var xmlString = '';

    var req = http.request(options, function (res) {
        console.log('[rtvae response : ' + res.statusCode);

        res.setEncoding('utf8');

        res.on('data', function (chunk) {
            console.log(chunk);
            if (res.headers['x-m2m-rsc'] == 5106 || res.headers['x-m2m-rsc'] == 2001 || res.headers['x-m2m-rsc'] == 4015) {
                sh_state = 'crtae2';
            }
        });
    });

    req.on('error', function (e) {
        if (e.message != 'read ECONNRESET') {
            console.log('problem with request: ' + e.message);
        }
    });

    req.write(xmlString);
    req.end();
};

exports.crtct = function (cbhost, cbport, cbname, appid, appname, ctname, callback) {
    var cur_d = new Date();
    var cur_o = cur_d.getTimezoneOffset() / (-60);
    cur_d.setHours(cur_d.getHours() + cur_o);
    var msec = '';
    if ((parseInt(cur_d.getMilliseconds(), 10) < 10)) {
        msec = ('00' + cur_d.getMilliseconds());
    } else if ((parseInt(cur_d.getMilliseconds(), 10) < 100)) {
        msec = ('0' + cur_d.getMilliseconds());
    } else {
        msec = cur_d.getMilliseconds();
    }
    requestid = 'RI' + cur_d.toISOString().replace(/-/, '').replace(/-/, '').replace(/T/, '').replace(/:/, '').replace(/:/, '').replace(/\..+/, '') + msec;

    var results_ct = {};
    results_ct.lbl = 'seahorese';

    results_ct['@'] = {
        "xmlns:m2m": "http://www.onem2m.org/xml/protocols",
        "xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance"
    };

    var xmlString = js2xmlparser("m2m:cnt", results_ct);

    var path = '/' + cbname + '/' + appname;
    var options = {
        hostname: cbhost,
        port: cbport,
        path: path,
        method: 'post',
        headers: {
            'locale': 'ko',
            'X-M2M-RI': requestid,
            'Accept': 'application/xml',
            'X-M2M-Origin': appid,
            'X-M2M-NM': ctname,
            'Content-Type': 'application/vnd.onem2m-res+xml; ty=3',
            'Content-Length': xmlString.length
        }
    };

    var req = http.request(options, function (res) {
        console.log('[crtct response : ' + res.statusCode);

        res.setEncoding('utf8');

        res.on('data', function (chunk) {
            //if(res.headers['x-m2m-rsc'] == 5106 || res.headers['x-m2m-rsc'] == 2001 || res.headers['x-m2m-rsc'] == 4015 || res.headers['x-m2m-rsc'] == 4105) {
            //    sh_state = 'delsub';
            //}
            //else if(res.headers['x-m2m-rsc'] == 5000) {
            //    sh_state = 'crtae';
            //}
            callback(res.headers['x-m2m-rsc'], ctname);
        });
    });

    req.on('error', function (e) {
        if (e.message != 'read ECONNRESET') {
            console.log('problem with request: ' + e.message);
        }
    });

    console.log(xmlString);
    req.write(xmlString);
    req.end();
};


exports.rtvct = function (cbhost, cbport, cbname, appid, appname, ctname) {
    var cur_d = new Date();
    var cur_o = cur_d.getTimezoneOffset() / (-60);
    cur_d.setHours(cur_d.getHours() + cur_o);
    var msec = '';
    if ((parseInt(cur_d.getMilliseconds(), 10) < 10)) {
        msec = ('00' + cur_d.getMilliseconds());
    } else if ((parseInt(cur_d.getMilliseconds(), 10) < 100)) {
        msec = ('0' + cur_d.getMilliseconds());
    } else {
        msec = cur_d.getMilliseconds();
    }
    requestid = 'RI' + cur_d.toISOString().replace(/-/, '').replace(/-/, '').replace(/T/, '').replace(/:/, '').replace(/:/, '').replace(/\..+/, '') + msec;

    var xmlString = '';

    var path = '/' + cbname + '/' + appname + '/' + ctname;
    var options = {
        hostname: cbhost,
        port: cbport,
        path: path,
        method: 'get',
        headers: {
            'locale': 'ko',
            'X-M2M-RI': requestid,
            'Accept': 'application/xml',
            'X-M2M-Origin': appid,
            'Content-Type': 'application/vnd.onem2m-res+xml'
        }
    };

    var req = http.request(options, function (res) {
        console.log('[rtvct response : ' + res.statusCode);

        res.setEncoding('utf8');

        res.on('data', function (chunk) {
            if (res.headers['x-m2m-rsc'] == 5106 || res.headers['x-m2m-rsc'] == 2001 || res.headers['x-m2m-rsc'] == 4015) {
                sh_state = 'delsub';
            } else if (res.headers['x-m2m-rsc'] == 5000) {
                sh_state = 'crtae';
            }
        });
    });

    req.on('error', function (e) {
        if (e.message != 'read ECONNRESET') {
            console.log('problem with request: ' + e.message);
        }
    });

    req.write(xmlString);
    req.end();
};


exports.uptct = function (cbhost, cbport, cbname, appid, appname, ctname) {
    var cur_d = new Date();
    var cur_o = cur_d.getTimezoneOffset() / (-60);
    cur_d.setHours(cur_d.getHours() + cur_o);
    var msec = '';
    if ((parseInt(cur_d.getMilliseconds(), 10) < 10)) {
        msec = ('00' + cur_d.getMilliseconds());
    } else if ((parseInt(cur_d.getMilliseconds(), 10) < 100)) {
        msec = ('0' + cur_d.getMilliseconds());
    } else {
        msec = cur_d.getMilliseconds();
    }
    requestid = 'RI' + cur_d.toISOString().replace(/-/, '').replace(/-/, '').replace(/T/, '').replace(/:/, '').replace(/:/, '').replace(/\..+/, '') + msec;

    var xmlString = '';
    var results_ct = {};
    results_ct.lbl = 'seahorese/' + ctname;

    results_ct['@'] = {
        "xmlns:m2m": "http://www.onem2m.org/xml/protocols",
        "xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance"
    };

    xmlString = js2xmlparser("m2m:cnt", results_ct);

    var path = '/' + cbname + '/' + appname + '/' + ctname;
    var options = {
        hostname: cbhost,
        port: cbport,
        path: path,
        method: 'put',
        headers: {
            'locale': 'ko',
            'X-M2M-RI': requestid,
            'Accept': 'application/xml',
            'X-M2M-Origin': appid,
            'Content-Type': 'application/vnd.onem2m-res+xml; ty=3'
        }
    };

    var req = http.request(options, function (res) {
        console.log('[uptct response : ' + res.statusCode);

        res.setEncoding('utf8');

        res.on('data', function (chunk) {
            if (res.headers['x-m2m-rsc'] == 5106 || res.headers['x-m2m-rsc'] == 2001 || res.headers['x-m2m-rsc'] == 4015) {
                sh_state = 'delsub';
            } else if (res.headers['x-m2m-rsc'] == 5000) {
                sh_state = 'crtae';
            }
        });
    });

    req.on('error', function (e) {
        if (e.message != 'read ECONNRESET') {
            console.log('problem with request: ' + e.message);
        }
    });

    console.log(xmlString);
    req.write(xmlString);
    req.end();
};


exports.delct = function (cbhost, cbport, cbname, appid, appname, ctname) {
    var cur_d = new Date();
    var cur_o = cur_d.getTimezoneOffset() / (-60);
    cur_d.setHours(cur_d.getHours() + cur_o);
    var msec = '';
    if ((parseInt(cur_d.getMilliseconds(), 10) < 10)) {
        msec = ('00' + cur_d.getMilliseconds());
    } else if ((parseInt(cur_d.getMilliseconds(), 10) < 100)) {
        msec = ('0' + cur_d.getMilliseconds());
    } else {
        msec = cur_d.getMilliseconds();
    }
    requestid = 'RI' + cur_d.toISOString().replace(/-/, '').replace(/-/, '').replace(/T/, '').replace(/:/, '').replace(/:/, '').replace(/\..+/, '') + msec;

    var xmlString = '';

    var path = '/' + cbname + '/' + appname + '/' + ctname;
    var options = {
        hostname: cbhost,
        port: cbport,
        path: path,
        method: 'delete',
        headers: {
            'locale': 'ko',
            'X-M2M-RI': requestid,
            'Accept': 'application/xml',
            'X-M2M-Origin': appid,
            'Content-Type': 'application/vnd.onem2m-res+xml'
        }
    };

    var req = http.request(options, function (res) {
        console.log('[delct response : ' + res.statusCode);

        res.setEncoding('utf8');

        res.on('data', function (chunk) {
            if (res.headers['x-m2m-rsc'] == 5106 || res.headers['x-m2m-rsc'] == 2001 || res.headers['x-m2m-rsc'] == 4015) {
                sh_state = 'delsub';
            } else if (res.headers['x-m2m-rsc'] == 5000) {
                sh_state = 'crtae';
            }
        });
    });

    req.on('error', function (e) {
        if (e.message != 'read ECONNRESET') {
            console.log('problem with request: ' + e.message);
        }
    });

    req.write(xmlString);
    req.end();
};


exports.delsub = function (cbhost, cbport, cbname, appid, appname, ctname, subname, nu, callback) {
    var cur_d = new Date();
    var cur_o = cur_d.getTimezoneOffset() / (-60);
    cur_d.setHours(cur_d.getHours() + cur_o);
    var msec = '';
    if ((parseInt(cur_d.getMilliseconds(), 10) < 10)) {
        msec = ('00' + cur_d.getMilliseconds());
    } else if ((parseInt(cur_d.getMilliseconds(), 10) < 100)) {
        msec = ('0' + cur_d.getMilliseconds());
    } else {
        msec = cur_d.getMilliseconds();
    }
    requestid = 'RI' + cur_d.toISOString().replace(/-/, '').replace(/-/, '').replace(/T/, '').replace(/:/, '').replace(/:/, '').replace(/\..+/, '') + msec;

    var path = '/' + cbname + '/' + appname + '/' + ctname + '/' + subname;
    var options = {
        hostname: cbhost,
        port: cbport,
        path: path,
        method: 'delete',
        headers: {
            'locale': 'ko',
            'X-M2M-RI': requestid,
            'Accept': 'application/xml',
            'X-M2M-Origin': appid,
            'Content-Type': 'application/vnd.onem2m-res+xml'
        }
    };

    var req = http.request(options, function (res) {
        console.log('[delsub response : ' + res.statusCode);

        res.setEncoding('utf8');
        if (res.headers['content-type'] == null) {
            callback(res.headers['x-m2m-rsc']);
        }
        //sh_state = 'crtsub';
        res.on('data', function (chunk) {
            //if(res.headers['x-m2m-rsc'] == 5106 || res.headers['x-m2m-rsc'] == 2001 || res.headers['x-m2m-rsc'] == 2000 || res.headers['x-m2m-rsc'] == 4015 || res.headers['x-m2m-rsc'] == 4004) {
            //    sh_state = 'crtsub';
            //}
            //else if(res.headers['x-m2m-rsc'] == 5000) {
            //    sh_state = 'crtsub';
            //}
            //else {
            //    sh_state = 'crtsub';
            //}
            callback(res.headers['x-m2m-rsc'], ctname);
        });
    });

    req.on('error', function (e) {
        if (e.message != 'read ECONNRESET') {
            console.log('problem with request: ' + e.message);
        }
    });

    req.write('');
    req.end();
};

exports.crtsub = function (cbhost, cbport, cbname, appid, appname, ctname, subname, nu, callback) {
    var cur_d = new Date();
    var cur_o = cur_d.getTimezoneOffset() / (-60);
    cur_d.setHours(cur_d.getHours() + cur_o);
    var msec = '';
    if ((parseInt(cur_d.getMilliseconds(), 10) < 10)) {
        msec = ('00' + cur_d.getMilliseconds());
    } else if ((parseInt(cur_d.getMilliseconds(), 10) < 100)) {
        msec = ('0' + cur_d.getMilliseconds());
    } else {
        msec = cur_d.getMilliseconds();
    }
    requestid = 'RI' + cur_d.toISOString().replace(/-/, '').replace(/-/, '').replace(/T/, '').replace(/:/, '').replace(/:/, '').replace(/\..+/, '') + msec;

    var results_ss = {};
    results_ss.enc = {evt: 3};
    results_ss.nu = nu;
    results_ss.nct = 2;

    results_ss['@'] = {
        "xmlns:m2m": "http://www.onem2m.org/xml/protocols",
        "xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance"
    };

    var xmlString = js2xmlparser("m2m:sub", results_ss);

    var path = '/' + cbname + '/' + appname + '/' + ctname;
    var options = {
        hostname: cbhost,
        port: cbport,
        path: path,
        method: 'post',
        headers: {
            'locale': 'ko',
            'X-M2M-RI': requestid,
            'Accept': 'application/xml',
            'X-M2M-Origin': appid,
            'X-M2M-NM': subname,
            'Content-Type': 'application/vnd.onem2m-res+xml; ty=23',
            'Content-Length': xmlString.length
        }
    };

    var req = http.request(options, function (res) {
        console.log('[crtsub response : ' + res.statusCode);

        res.setEncoding('utf8');

        res.on('data', function (chunk) {
            //if(res.headers['x-m2m-rsc'] == 5106 || res.headers['x-m2m-rsc'] == 2001 || res.headers['x-m2m-rsc'] == 4015 || res.headers['x-m2m-rsc'] == 4105) {
            //    sh_state = 'crtci';
            //}
            //else if(res.headers['x-m2m-rsc'] == 5000) {
            //    sh_state = 'crtae';
            //}
            callback(res.headers['x-m2m-rsc'], ctname);
        });
    });

    req.on('error', function (e) {
        if (e.message != 'read ECONNRESET') {
            console.log('problem with request: ' + e.message);
        }
    });

    //console.log(xmlString);
    req.write(xmlString);
    req.end();
};

exports.crtci = function (cbhost, cbport, cbname, appid, appname, ctname, content, callback) {
    var cur_d = new Date();
    var cur_o = cur_d.getTimezoneOffset() / (-60);
    cur_d.setHours(cur_d.getHours() + cur_o);
    var msec = '';
    if ((parseInt(cur_d.getMilliseconds(), 10) < 10)) {
        msec = ('00' + cur_d.getMilliseconds());
    } else if ((parseInt(cur_d.getMilliseconds(), 10) < 100)) {
        msec = ('0' + cur_d.getMilliseconds());
    } else {
        msec = cur_d.getMilliseconds();
    }
    requestid = 'RI' + cur_d.toISOString().replace(/-/, '').replace(/-/, '').replace(/T/, '').replace(/:/, '').replace(/:/, '').replace(/\..+/, '') + msec;

    var results_ci = {};
    results_ci.con = content;

    results_ci['@'] = {
        "xmlns:m2m": "http://www.onem2m.org/xml/protocols",
        "xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance"
    };

    var xmlString = js2xmlparser("m2m:cin", results_ci);

    var path = '/' + cbname + '/' + appname + '/' + ctname;
    var options = {
        hostname: cbhost,
        port: cbport,
        path: path,
        method: 'post',
        headers: {
            'locale': 'ko',
            'X-M2M-RI': requestid,
            'Accept': 'application/xml',
            'X-M2M-Origin': appid,
            'Content-Type': 'application/vnd.onem2m-res+xml; ty=4',
            'Content-Length': xmlString.length
        }
    };

    var req = http.request(options, function (res) {
        console.log('[crtci response : ' + res.statusCode);

        res.setEncoding('utf8');

        res.on('data', function (chunk) {
            //if(res.headers['x-m2m-rsc'] == 5106 || res.headers['x-m2m-rsc'] == 2001 || res.headers['x-m2m-rsc'] == 4015) {
            //    sh_state = 'crtci';
            //    socket.write('{\"ctname\":\"'+ctname+'\",\"con\":\"201\"}');
            //}
            //else if(res.headers['x-m2m-rsc'] == 5000) {
            //    sh_state = 'crtae';
            //    socket.write('{\"ctname\":\"'+ctname+'\",\"con\":\"'+res.statusCode+'\"}');
            //}
            //else {
            //    socket.write('{\"ctname\":\"'+ctname+'\",\"con\":\"'+res.statusCode+'\"}');
            //}
            callback(res.headers['x-m2m-rsc'], ctname);
        });
    });

    req.on('error', function (e) {
        if (e.message != 'read ECONNRESET') {
            console.log('problem with request: ' + e.message);
//            socket.write('{\"ctname\":\"' + ctname + '\",\"con\":\"' + e.message + '\"}');
        }
    });

    //console.log(xmlString);
    req.write(xmlString);
    console.log('[crtci request]');
    req.end();
};

