var kangaBaseNode = require('../common/kanga-base-node');
var extend = require('../../utils/kanga-common').extend;
var KANGA_EVENT = require('../../constants/kanga-event-type');

function ReFormat(params) {
    kangaBaseNode.call(this, params);
    this.keyFieldName = params.key_field_name;
    this.valueFieldName = params.value_field_name;
    this.locale = params.locale;
}

extend(ReFormat, kangaBaseNode);

ReFormat.prototype._execute = function () {
    this.klogger.debug('ReFormat ' + JSON.stringify(this.eventType));

    switch (this.eventType) {
        case KANGA_EVENT.DATA:
            var key = this.message[this.keyFieldName];
            var value = this.message[this.valueFieldName];

            var obj = new Object();
            var date = new Date();
            obj.x = date.toLocaleDateString(this.locale) + ' ' + date.toLocaleTimeString(this.locale);
            obj.y = Number(value);
            obj.min = 0;
            obj.max = 0;
            obj.stdev = 0;
            obj.avg = 0;

            var jsonInfo = new Object();
            jsonInfo[key] = obj;
            this.message = jsonInfo;
            this.event.root._header_.name = key;
            this.event.root[key] = jsonInfo;
            delete this.root[this.messageName];

            this.klogger.debug('ReFormat ' + JSON.stringify(this.message));
            this.klogger.debug('ReFormat ' + JSON.stringify(this.event));
            break;
        case KANGA_EVENT.COLLECTION:
            break;
        case KANGA_EVENT.TIME_TICK:
            break;
        case KANGA_EVENT.EOF:
            break;
        case KANGA_EVENT.SYSTEM_LOG:
            break;
        default:
            break;
    }
    return this.event;
};

module.exports = ReFormat;