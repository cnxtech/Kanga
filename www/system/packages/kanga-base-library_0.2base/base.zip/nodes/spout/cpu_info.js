var kangaBaseNode = require('../common/kanga-base-node');
var extend = require('../../utils/kanga-common').extend;
var os = require('os');
var ip = require("ip");

function CPUInfo(params) {
    kangaBaseNode.call(this, params);
    this.sleepingTime = params.sleeping_time;
}

extend(CPUInfo, kangaBaseNode);

CPUInfo.prototype.generateEvents = function (kangaEmitter, isClone) {
    var self = this;

    setInterval(function () {
        var loads = os.loadavg();

        self.klogger.debug('CPUInfo: os.loadavg() ' + loads);

        var event = new Object();
        var root = new Object();
        var header = new Object();
        var message = new Object();

        header.log = "";
        header.type = 0;
        header.timestamp = new Date().getTime();
        header.name = 'CPU_' + ip.address();
        root._header_ = header;
        message.x = date.toLocaleDateString(this.locale) + ' ' + date.toLocaleTimeString(this.locale);
        var loads = loads.toString().split(',');
        message.y = Number(loads[0]);
        
        root[header.name] = message;
        event.root = root;

        kangaEmitter(event, isClone);        
        self.setReceivedCount();
        
        console.log(event);

    }, this.sleepingTime);
}

module.exports = CPUInfo;
