
var kangaBaseNode = require('../common/kanga-base-node');
var extend = require('../../utils/kanga-common').extend;
var mqtt = require('mqtt');

function MQTTReader(params) {
  kangaBaseNode.call(this,params);
  var hostport = params.host.split(':');

  this.host = hostport[0];
  this.port = hostport[1];
  this.topicname = params.topic;
  this.outputname = params.output_name;
}

extend(MQTTReader, kangaBaseNode);


MQTTReader.prototype.generateEvents = function(eventEmitter, createCopy) {
   var self = this;
   var client = mqtt.connect('mqtt://'+self.host+':'+self.port);

   client.on('connect', function() {
     client.subscribe(self.topicname);
   });

   client.on('message', function(topic, message) {
     if (self.topicname == topic) {
       var event = new Object();
       var root = new Object();
       var header = new Object();

       header.log = "";
       header.type = 0;
       header.timestamp = new Date().getTime();
       header.name = self.outputname;

       root._header_ = header;

       root[header.name] = message.toString();
       event.root = root;
       eventEmitter(event, createCopy);
     }
   });

   client.on('error', function(err){
     self.klogger.error('MQTTReader: [Error] ' + err.message);
   });

   client.on('close', function() {
     self.klogger.debug('MQTTReader: connection closed');
   });
}

module.exports = MQTTReader;