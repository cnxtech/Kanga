var KangaBaseNode = function (params) {
    this.event;
    this.root;
    this.header;
    this.messageName;
    this.message;
    this.eventType;
    this.emittedCount = 0;
    this.receivedCount = 0;
    this.failedCount = 0;
    this.errorMessage = null;
    this.klogger = params.klogger;
    this.outputName = params.output_name;
}

KangaBaseNode.prototype.setReceivedCount = function () {
    this.receivedCount++;
};

KangaBaseNode.prototype.setEmittedCount = function () {
    this.emittedCount++;
};

KangaBaseNode.prototype.setFailedCount = function () {
    this.failedCount++;
};

KangaBaseNode.prototype.setErrorMessage = function (errorMessage) {
    this.errorMessage = errorMessage;
};

KangaBaseNode.prototype.getNodeStatus = function () {
    var nodeInfo = {};
    nodeInfo['emittedCount'] = this.emittedCount;
    nodeInfo['failedCount'] = this.failedCount;
    nodeInfo['receivedCount'] = this.receivedCount;
    nodeInfo['errorMessage'] = this.errorMessage;
    return nodeInfo;
};

KangaBaseNode.prototype.execute = function (_event) {
    this.setReceivedCount();
    try {
        this.event = _event;
        this.root = _event.root;
        this.header = this.root._header_;
        this.messageName = this.header.name;
        this.eventType = this.header.type;
        this.message = this.root[this.messageName];
        

        this.event = this._execute();
        
        if (this.event != null) {
            this.setEmittedCount();
            if (typeof this.outputName != "undefined" && this.outputName != this.messageName) {
                this.klogger.debug('KangaBaseNode: messageName is changed ' +
                        JSON.stringify(this.messageName) + ' to ' + JSON.stringify(this.outputName));
                this.header.name = this.outputName;
                this.root[this.outputName] = this.message;
                delete this.root[this.messageName];
            }
        }
        return this.event;
    } catch (e) {
        this.klogger.warn('KangaBaseNode: execute failed ' + e.message);
        this.setFailedCount();
        this.setErrorMessage(e.message);
    }
}

KangaBaseNode.prototype._execute = function () {

}
module.exports = KangaBaseNode;