var kangaBaseNode = require('../common/kanga-base-node');
var extend = require('../../utils/kanga-common').extend;

function Median(params) {
    kangaBaseNode.call(this, params);
    this.inputFieldName = params.input_field_name;
    this.windowSize = params.window_size;
    this.values = [];
}

extend(Median, kangaBaseNode);

Median.prototype._execute = function () {
    switch (this.eventType) {
        case 0: // data            
            this.klogger.debug('Median: ' + JSON.stringify(this.message));
            var value = this.message[this.inputFieldName];
            this.values.push(Number(value));

            //console.log(this.values);
            var sortedValues = this.values.slice().sort();
            //console.log('sorted ' + this.values);

            // Median
            var half = Math.floor(sortedValues.length / 2);
            var res;
            if (sortedValues.length % 2) {
                res = sortedValues[half];
            } else {
                res = (sortedValues[half - 1] + sortedValues[half]) / 2.0;
            }

            if (this.values.length == this.windowSize) {
                this.values.shift();
            }
            this.message[this.inputFieldName] = res;
            break;
        default:
            return null;
            break;
    }
    return this.event;
};

module.exports = Median;