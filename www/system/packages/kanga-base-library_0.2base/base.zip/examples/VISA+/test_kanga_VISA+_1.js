var kangaBase = '../../';
var events = require('events');
var clone = require(kangaBase + 'utils/kanga-common').clone;
var kangaLogger = require(kangaBase + 'utils/kanga-logger.js');
var kangaEmitter = new events.EventEmitter();
var node = {};
var log = new kangaLogger();
log.topologyLog('KangaTopology2', 'debug');
var klogger = log.getTopologyLog('KangaTopology2');


var TCPServer = require(kangaBase + "nodes/spout/tcp-server");
var SaveToFile = require(kangaBase + "nodes/sink/save-to-file");
var ToSocketIO = require(kangaBase + "nodes/sink/to-socket-io");
var ReFormat = require(kangaBase + "nodes/oneM2M/reformat");

var flowchart_tcp_server_880_params = {
    output_name: "main.py",
    klogger: klogger,
    port: "7622"
};
node["flowchart_tcp_server_880"] = new TCPServer(flowchart_tcp_server_880_params);


var flowchart_to_file_871_params = {
    output_file_path: "tcpserver_output_1.json",
    klogger: klogger
};
node["flowchart_to_file_871"] = new SaveToFile(flowchart_to_file_871_params);

var flowchart_reformat_333_params = {
    klogger: klogger
};
node["flowchart_reformat_333"] = new ReFormat(flowchart_reformat_333_params);

var flowchart_to_socket_io_123_params = {
    host: "localhost:3000",
    topicname: "oneM2M",
    klogger: klogger
};
node["flowchart_to_socket_io_123"] = new ToSocketIO(flowchart_to_socket_io_123_params);


var flowchart_tcp_server_880 = function () {
    klogger.debug('Flow flowchart_tcp_server_880');
    node["flowchart_tcp_server_880"].generateEvents(
            kangaEmitter.emit.bind(kangaEmitter, "flowchart_tcp_server_880"),
            true);
};

var flowchart_to_file_871 = function (event, isClone) {
    klogger.debug('Flow flowchart_to_file_871');
    event = node["flowchart_to_file_871"].execute((isClone == true) ? clone(event) : event);
    kangaEmit("flowchart_to_file_871", event, false);
};

var flowchart_reformat_333 = function (event, isClone) {
    klogger.debug('Flow flowchart_reformat_333');
    event = node["flowchart_reformat_333"].execute((isClone == true) ? clone(event) : event);
    kangaEmit("flowchart_reformat_333", event, false);
};

var flowchart_to_socket_io_123 = function (event, isClone) {
    klogger.debug('Flow flowchart_to_socket_io_123');
    event = node["flowchart_to_socket_io_123"].execute((isClone == true) ? clone(event) : event);
    kangaEmit("flowchart_to_socket_io_123", event, false);
};

kangaEmitter.on("start", flowchart_tcp_server_880);
kangaEmitter.on("flowchart_tcp_server_880", flowchart_to_file_871);
kangaEmitter.on("flowchart_tcp_server_880", flowchart_reformat_333);
kangaEmitter.on("flowchart_reformat_333", flowchart_to_socket_io_123);

klogger.info('Flow Started');
kangaEmitter.emit("start");

function kangaEmit(eId, event, isClone) {
    if (event != null) {
        if (event.constructor == Array) {
            for (var i = 0; i < event.length; i++) {
                kangaEmitter.emit(eId, event[i], isClone);
            }
        } else {
            kangaEmitter.emit(eId, event, isClone);
        }
    }
}
