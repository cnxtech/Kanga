var kangaBase = '../../../';
var events = require('events');
var clone = require(kangaBase + 'utils/common').clone;
var kangaLogger = require(kangaBase + 'utils/kanga.logger.js');
var kanga = new events.EventEmitter();
var node = {};
var log = new kangaLogger();
log.topologyLog('KangaTopology2','info');
var klogger = log.getTopologyLog('KangaTopology2')


var SplitBolt = require(kangaBase + "nodes/function/com.sec.kanga.bolt.transform.SplitBolt");
var FileReaderSpout = require(kangaBase + "nodes/input/com.sec.kanga.spout.FileReaderSpout");
var SaveToFile = require(kangaBase + "nodes/output/com.sec.kanga.bolt.sink.SaveToFile");

var flowchart_from_file_278_params={output_name:"empolyee",event_type:"DATA",file_path:"../input_single_line.json",sleeping_time:"1000",klogger:klogger};
node["flowchart_from_file_278"]=new FileReaderSpout(flowchart_from_file_278_params);

var flowchart_split_802_params={input_field_name:"email",delimiter:"@",output_field_names:"id,domain",output_name:"employees",klogger:klogger};
node["flowchart_split_802"]=new SplitBolt(flowchart_split_802_params);

var flowchart_to_file_231_params={output_file_path:"transform_output.json",klogger:klogger};
node["flowchart_to_file_231"]=new SaveToFile(flowchart_to_file_231_params);

var flowchart_from_file_278 = function(){
	node["flowchart_from_file_278"].generateEvents(kanga.emit.bind(kanga,"flowchart_from_file_278"));
}
var flowchart_split_802 = function(event){
	event = node["flowchart_split_802"].processData(clone(event));
	kanga.emit("flowchart_split_802",event);
}
var flowchart_to_file_231 = function(event){
	event = node["flowchart_to_file_231"].processData(clone(event));
	kanga.emit("flowchart_to_file_231",event);
}


kanga.on("start",flowchart_from_file_278);
kanga.on("flowchart_from_file_278",flowchart_split_802);
kanga.on("flowchart_split_802",flowchart_to_file_231);
kanga.emit("start");
klogger.info('Flow Started')
