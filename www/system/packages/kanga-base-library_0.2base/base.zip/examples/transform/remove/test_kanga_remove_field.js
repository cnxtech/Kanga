var kangaBase = '../../../';
var events = require('events');
var clone = require(kangaBase + 'utils/common').clone;
var kangaLogger = require(kangaBase + 'utils/kanga.logger.js');
var kanga = new events.EventEmitter();
var node = {};
var log = new kangaLogger();
log.topologyLog('KangaTopology1','info');
var klogger = log.getTopologyLog('KangaTopology1')


var SaveToFile = require(kangaBase + "nodes/output/com.sec.kanga.bolt.sink.SaveToFile");
var RemoveFieldsBolt = require(kangaBase + "nodes/function/com.sec.kanga.bolt.transform.RemoveFieldsBolt");
var FileReaderSpout = require(kangaBase + "nodes/input/com.sec.kanga.spout.FileReaderSpout");

var flowchart_from_file_558_params={output_name:"persons",event_type:"DATA",file_path:"../input_single_line.json",sleeping_time:"0",klogger:klogger};
node["flowchart_from_file_558"]=new FileReaderSpout(flowchart_from_file_558_params);

var flowchart_remove_fields_363_params={input_field_names:"name,gender",output_name:"employee",klogger:klogger};
node["flowchart_remove_fields_363"]=new RemoveFieldsBolt(flowchart_remove_fields_363_params);

var flowchart_to_file_751_params={output_file_path:"transform_output.json",klogger:klogger};
node["flowchart_to_file_751"]=new SaveToFile(flowchart_to_file_751_params);

var flowchart_from_file_558 = function(){
	node["flowchart_from_file_558"].generateEvents(kanga.emit.bind(kanga,"flowchart_from_file_558"));
}
var flowchart_remove_fields_363 = function(event){
	event = node["flowchart_remove_fields_363"].processData(clone(event));
	kanga.emit("flowchart_remove_fields_363",event);
}
var flowchart_to_file_751 = function(event){
	event = node["flowchart_to_file_751"].processData(clone(event));
	kanga.emit("flowchart_to_file_751",event);
}


kanga.on("start",flowchart_from_file_558);
kanga.on("flowchart_remove_fields_363",flowchart_to_file_751);
kanga.on("flowchart_from_file_558",flowchart_remove_fields_363);
kanga.emit("start");
klogger.info('Flow Started')
