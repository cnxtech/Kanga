var kangaBase = '../../../';
var events = require('events');
var clone = require(kangaBase + 'utils/common').clone;
var kangaLogger = require(kangaBase + 'utils/kanga.logger.js');
var kanga = new events.EventEmitter();
var node = {};
var log = new kangaLogger();
log.topologyLog('KangaTopology','info');
var klogger = log.getTopologyLog('KangaTopology')


var hoeffdingTree = require(kangaBase + "nodes/function/com.sec.kanga.bolt.classify.hoeffdingTree");
var SaveToFile = require(kangaBase + "nodes/output/com.sec.kanga.bolt.sink.SaveToFile");
var ClassificationFileReaderSpout = require(kangaBase + "nodes/input/com.sec.kanga.spout.ClassificationFileReaderSpout");

var flowchart_hoeffding_tree_197_params={output_name:"data",instances_between_splits:"100",split_criterion:"InformationGain",delta:"1",tie_threshold:"1",disable_pre_pruning:"True",instances_before_splits:"100",leaf_classifier:"NaiveBayesAdaptive",prediction_threshold:"10",max_active_nodes:"10000",klogger:klogger};
node["flowchart_hoeffding_tree_197"]=new hoeffdingTree(flowchart_hoeffding_tree_197_params);

var flowchart_from_classify_file_100_params={sleeping_time:"0",output_name:"data",file_path:"./inpSYN.txt",event_type:"DATA",klogger:klogger};
node["flowchart_from_classify_file_100"]=new ClassificationFileReaderSpout(flowchart_from_classify_file_100_params);

var flowchart_to_file_127_params={output_file_path:"./test_output.json",klogger:klogger};
node["flowchart_to_file_127"]=new SaveToFile(flowchart_to_file_127_params);

var flowchart_hoeffding_tree_197 = function(event){
	event = node["flowchart_hoeffding_tree_197"].processData(clone(event));
	kanga.emit("flowchart_hoeffding_tree_197",event);
}
var flowchart_from_classify_file_100 = function(){
	node["flowchart_from_classify_file_100"].generateEvents(kanga.emit.bind(kanga,"flowchart_from_classify_file_100"));
}
var flowchart_to_file_127 = function(event){
	event = node["flowchart_to_file_127"].processData(clone(event));
	kanga.emit("flowchart_to_file_127",event);
}


kanga.on("start",flowchart_from_classify_file_100);
kanga.on("flowchart_from_classify_file_100",flowchart_hoeffding_tree_197);
kanga.on("flowchart_hoeffding_tree_197",flowchart_to_file_127);
kanga.emit("start");
klogger.info('Flow Started')
