var kangaBase = '../../../';
var events = require('events');
var clone = require(kangaBase + 'utils/common').clone;
var kangaLogger = require(kangaBase + 'utils/kanga.logger.js');
var kanga = new events.EventEmitter();
var node = {};
var log = new kangaLogger();
log.topologyLog('KangaTopology','info');
var klogger = log.getTopologyLog('KangaTopology')


var SaveToFile = require(kangaBase + "nodes/output/com.sec.kanga.bolt.sink.SaveToFile");
var RemoveFieldsBolt = require(kangaBase + "nodes/function/com.sec.kanga.bolt.transform.RemoveFieldsBolt");
var SplitBolt = require(kangaBase + "nodes/function/com.sec.kanga.bolt.transform.SplitBolt");
var kmeans = require(kangaBase + "nodes/function/com.sec.kanga.bolt.cluster.kmeans");
var RawFileReaderSpout = require(kangaBase + "nodes/input/com.sec.kanga.spout.RawFileReaderSpout");

var flowchart_from_raw_file_200_params={sleeping_time:"0",output_name:"data",file_path:"input.txt",event_type:"DATA",klogger:klogger};
node["flowchart_from_raw_file_200"]=new RawFileReaderSpout(flowchart_from_raw_file_200_params);

var flowchart_kmeanspp_575_params={num_clusters:"3",num_init_points:"10",output_name:"points",klogger:klogger};
node["flowchart_kmeanspp_575"]=new kmeans(flowchart_kmeanspp_575_params);

var flowchart_to_file_238_params={output_file_path:"test_output.json",klogger:klogger};
node["flowchart_to_file_238"]=new SaveToFile(flowchart_to_file_238_params);

var flowchart_split_900_params={input_field_name:"points",delimiter:" ",output_field_names:"X,Y",output_name:"points",klogger:klogger};
node["flowchart_split_900"]=new SplitBolt(flowchart_split_900_params);

var flowchart_remove_fields_546_params={input_field_names:"points",output_name:"points",klogger:klogger};
node["flowchart_remove_fields_546"]=new RemoveFieldsBolt(flowchart_remove_fields_546_params);

var flowchart_from_raw_file_200 = function(){
	node["flowchart_from_raw_file_200"].generateEvents(kanga.emit.bind(kanga,"flowchart_from_raw_file_200"));
}
var flowchart_kmeanspp_575 = function(event){
	event = node["flowchart_kmeanspp_575"].processData(clone(event));
	kanga.emit("flowchart_kmeanspp_575",event);
}
var flowchart_to_file_238 = function(event){
	event = node["flowchart_to_file_238"].processData(clone(event));
	kanga.emit("flowchart_to_file_238",event);
}
var flowchart_split_900 = function(event){
	event = node["flowchart_split_900"].processData(clone(event));
	kanga.emit("flowchart_split_900",event);
}
var flowchart_remove_fields_546 = function(event){
	event = node["flowchart_remove_fields_546"].processData(clone(event));
	kanga.emit("flowchart_remove_fields_546",event);
}


kanga.on("start",flowchart_from_raw_file_200);
kanga.on("flowchart_kmeanspp_575",flowchart_to_file_238);
kanga.on("flowchart_split_900",flowchart_remove_fields_546);
kanga.on("flowchart_remove_fields_546",flowchart_kmeanspp_575);
kanga.on("flowchart_from_raw_file_200",flowchart_split_900);
kanga.emit("start");
klogger.info('Flow Started')
