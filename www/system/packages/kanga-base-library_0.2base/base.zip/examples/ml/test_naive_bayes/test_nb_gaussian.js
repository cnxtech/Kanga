var kangaBase = '../../../';
var events = require('events');
var clone = require(kangaBase + 'utils/common').clone;
var kangaLogger = require(kangaBase + 'utils/kanga.logger.js');
var kanga = new events.EventEmitter();
var node = {};
var log = new kangaLogger();
log.topologyLog('KangaTopology','info');
var klogger = log.getTopologyLog('KangaTopology')


var ClassificationFileReaderSpout = require(kangaBase + "nodes/input/com.sec.kanga.spout.ClassificationFileReaderSpout");
var SaveToFile = require(kangaBase + "nodes/output/com.sec.kanga.bolt.sink.SaveToFile");
var naiveBayesGaussian = require(kangaBase + "nodes/function/com.sec.kanga.bolt.classify.naiveBayesGaussian");

var flowchart_from_classify_file_688_params={sleeping_time:"0",output_name:"data",file_path:"./inpNBG.txt",event_type:"DATA",klogger:klogger};
node["flowchart_from_classify_file_688"]=new ClassificationFileReaderSpout(flowchart_from_classify_file_688_params);

var flowchart_naive_bayes_gaussian_157_params={output_name:"data",klogger:klogger};
node["flowchart_naive_bayes_gaussian_157"]=new naiveBayesGaussian(flowchart_naive_bayes_gaussian_157_params);

var flowchart_to_file_97_params={output_file_path:"./test_output.json",klogger:klogger};
node["flowchart_to_file_97"]=new SaveToFile(flowchart_to_file_97_params);

var flowchart_from_classify_file_688 = function(){
	node["flowchart_from_classify_file_688"].generateEvents(kanga.emit.bind(kanga,"flowchart_from_classify_file_688"));
}
var flowchart_naive_bayes_gaussian_157 = function(event){
	event = node["flowchart_naive_bayes_gaussian_157"].processData(clone(event));
	kanga.emit("flowchart_naive_bayes_gaussian_157",event);
}
var flowchart_to_file_97 = function(event){
	event = node["flowchart_to_file_97"].processData(clone(event));
	kanga.emit("flowchart_to_file_97",event);
}


kanga.on("start",flowchart_from_classify_file_688);
kanga.on("flowchart_from_classify_file_688",flowchart_naive_bayes_gaussian_157);
kanga.on("flowchart_naive_bayes_gaussian_157",flowchart_to_file_97);
kanga.emit("start");
klogger.info('Flow Started')
