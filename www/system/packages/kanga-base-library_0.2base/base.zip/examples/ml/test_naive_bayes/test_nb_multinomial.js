var kangaBase = '../../../';
var events = require('events');
var clone = require(kangaBase + 'utils/common').clone;
var kangaLogger = require(kangaBase + 'utils/kanga.logger.js');
var kanga = new events.EventEmitter();
var node = {};
var log = new kangaLogger();
log.topologyLog('KangaTopology','info');
var klogger = log.getTopologyLog('KangaTopology')


var ClassificationFileReaderSpout = require(kangaBase + "nodes/input/com.sec.kanga.spout.ClassificationFileReaderSpout");
var SaveToFile = require(kangaBase + "nodes/output/com.sec.kanga.bolt.sink.SaveToFile");
var naiveBayesMultinomial = require(kangaBase + "nodes/function/com.sec.kanga.bolt.classify.naiveBayesMultinomial");

var flowchart_naive_bayes_multinomial_431_params={output_name:"data",laplace_correction:"True",klogger:klogger};
node["flowchart_naive_bayes_multinomial_431"]=new naiveBayesMultinomial(flowchart_naive_bayes_multinomial_431_params);

var flowchart_from_classify_file_495_params={sleeping_time:"0",output_name:"data",file_path:"./inpNBM.txt",event_type:"DATA",klogger:klogger};
node["flowchart_from_classify_file_495"]=new ClassificationFileReaderSpout(flowchart_from_classify_file_495_params);

var flowchart_to_file_766_params={output_file_path:"./test_output.json",klogger:klogger};
node["flowchart_to_file_766"]=new SaveToFile(flowchart_to_file_766_params);

var flowchart_naive_bayes_multinomial_431 = function(event){
	event = node["flowchart_naive_bayes_multinomial_431"].processData(clone(event));
	kanga.emit("flowchart_naive_bayes_multinomial_431",event);
}
var flowchart_from_classify_file_495 = function(){
	node["flowchart_from_classify_file_495"].generateEvents(kanga.emit.bind(kanga,"flowchart_from_classify_file_495"));
}
var flowchart_to_file_766 = function(event){
	event = node["flowchart_to_file_766"].processData(clone(event));
	kanga.emit("flowchart_to_file_766",event);
}


kanga.on("start",flowchart_from_classify_file_495);
kanga.on("flowchart_from_classify_file_495",flowchart_naive_bayes_multinomial_431);
kanga.on("flowchart_naive_bayes_multinomial_431",flowchart_to_file_766);
kanga.emit("start");
klogger.info('Flow Started')
