var kangaBase = '../../../';
var events = require('events');
var clone = require(kangaBase + 'utils/common').clone;
var kangaLogger = require(kangaBase + 'utils/kanga.logger.js');
var kanga = new events.EventEmitter();
var node = {};
var log = new kangaLogger();
log.topologyLog('KangaTopology','info');
var klogger = log.getTopologyLog('KangaTopology')


var naiveBayes = require(kangaBase + "nodes/function/com.sec.kanga.bolt.classify.naiveBayes");
var ClassificationFileReaderSpout = require(kangaBase + "nodes/input/com.sec.kanga.spout.ClassificationFileReaderSpout");
var SaveToFile = require(kangaBase + "nodes/output/com.sec.kanga.bolt.sink.SaveToFile");

var flowchart_naive_bayes_748_params={output_name:"data",klogger:klogger};
node["flowchart_naive_bayes_748"]=new naiveBayes(flowchart_naive_bayes_748_params);

var flowchart_to_file_267_params={output_file_path:"./test_output.json",klogger:klogger};
node["flowchart_to_file_267"]=new SaveToFile(flowchart_to_file_267_params);

var flowchart_from_classify_file_900_params={sleeping_time:"0",output_name:"data",file_path:"./inpNB.txt",event_type:"DATA",klogger:klogger};
node["flowchart_from_classify_file_900"]=new ClassificationFileReaderSpout(flowchart_from_classify_file_900_params);

var flowchart_naive_bayes_748 = function(event){
	event = node["flowchart_naive_bayes_748"].processData(clone(event));
	kanga.emit("flowchart_naive_bayes_748",event);
}
var flowchart_to_file_267 = function(event){
	event = node["flowchart_to_file_267"].processData(clone(event));
	kanga.emit("flowchart_to_file_267",event);
}
var flowchart_from_classify_file_900 = function(){
	node["flowchart_from_classify_file_900"].generateEvents(kanga.emit.bind(kanga,"flowchart_from_classify_file_900"));
}


kanga.on("start",flowchart_from_classify_file_900);
kanga.on("flowchart_from_classify_file_900",flowchart_naive_bayes_748);
kanga.on("flowchart_naive_bayes_748",flowchart_to_file_267);
kanga.emit("start");
klogger.info('Flow Started')
