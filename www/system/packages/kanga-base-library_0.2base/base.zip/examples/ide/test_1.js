var kangaBase = 'C:/Source/Git/Nodejs';
var events = require('events');
var clone = require(kangaBase + '/utils/kanga-common').clone;
var kangaLogger = require(kangaBase + '/utils/kanga-logger');
var kangaEmitter = new events.EventEmitter();
var node = {};
var log = new kangaLogger();

// Create the logger for the given topology
log.topologyLog("KangaTopology3","debug");
var klogger = log.getTopologyLog("KangaTopology3")

// Load all the required bolts
var savetofile = require(kangaBase + "/nodes/sink/save-to-file")
var filereader = require(kangaBase + "/nodes/spout/file-reader")

// Create an object with the required set of parameters
var flowchart_from_file_546_params = {}
flowchart_from_file_546_params.klogger = klogger
flowchart_from_file_546_params.output_name = "test"
flowchart_from_file_546_params.file_path = "C:/Source/Git/Nodejs/examples/transform/input_single_line.json"
flowchart_from_file_546_params.sleeping_time = "1000"
flowchart_from_file_546_params.event_type = "RAW"
node["flowchart_from_file_546"] = new filereader(flowchart_from_file_546_params)

var flowchart_to_file_78_params = {}
flowchart_to_file_78_params.klogger = klogger
flowchart_to_file_78_params.output_file_path = "c:/output.txt"
node["flowchart_to_file_78"] = new savetofile(flowchart_to_file_78_params)



// Define callback functions
var flowchart_from_file_546 = function(){
	node["flowchart_from_file_546"].generateEvents(kangaEmitter.emit.bind(kangaEmitter,"flowchart_from_file_546"), true);
}
var flowchart_to_file_78 = function(event, isClone){
	event = node["flowchart_to_file_78"].execute((isClone == true) ? clone(event) : event);
	kangaEmit("flowchart_to_file_78",event, true);
}

// Register the call back functions with kangaEmitter
kangaEmitter.on("start",flowchart_from_file_546)

kangaEmitter.on("flowchart_from_file_546",flowchart_to_file_78);

kangaEmitter.emit("start");
klogger.info("Flow Started");

function kangaEmit(eId, event, isClone) {
    if (event != null) {
        if (event.constructor == Array) {
            for (var i = 0; i < event.length; i++) {
                kangaEmitter.emit(eId, event[i], isClone);
            }
        } else {
            kangaEmitter.emit(eId, event, isClone);
        }
    }
}
