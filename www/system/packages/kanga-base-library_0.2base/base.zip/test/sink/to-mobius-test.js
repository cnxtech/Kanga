var assert = require("assert");
var kangaBase = '../../';
var ToMobius = require(kangaBase + "nodes/sink/to-mobius");
var kangaLogger = require(kangaBase + 'utils/kanga-logger.js');
var klogger = new kangaLogger('ToMobius', 'debug');

var params = {
    config_file_path: 'nodes/sink/conf.xml',
    key_field_name: 'ctname',
    value_field_name: 'con',
    sleeping_time: '1000',
    klogger: klogger
};
testNode = new ToMobius(params);
var data = '{"root":{"_header_":{"log":"","type":0,"timestamp":1455163028,"name":"unittest"},\n\
"unittest":{"ctname":"Kanga_10.251.21.98","con":"20160829"}}}';


//testNode.execute(JSON.parse(data.toString()));
setInterval(function () {
    testNode.execute(JSON.parse(data.toString()));
}, 1000);

