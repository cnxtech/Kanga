var assert = require("assert");
var kangaBase = '../../';
var Median = require(kangaBase + "nodes/aggregate/median");
var kangaLogger = require(kangaBase + 'utils/kanga-logger.js');
var log = new kangaLogger();
log.topologyLog('Median Test', 'debug');
var klogger = log.getTopologyLog('Median Test');

var params = {
    output_name: "median",
    input_field_name: "age",
    window_size: "3",
    klogger: klogger
};
testNode = new Median(params);

var inputData1 = '{"root":{"_header_":{"log":"","type":0,"timestamp":1455163028,"name":"person"},"person":{"age":"20","name":"jack"}}}';
var inputData2 = '{"root":{"_header_":{"log":"","type":0,"timestamp":1455163028,"name":"person"},"person":{"age":"25","name":"jack"}}}';
var inputData3 = '{"root":{"_header_":{"log":"","type":0,"timestamp":1455163028,"name":"person"},"person":{"age":"24","name":"jack"}}}';
var inputData4 = '{"root":{"_header_":{"log":"","type":0,"timestamp":1455163028,"name":"person"},"person":{"age":"23","name":"jack"}}}';
var inputData5 = '{"root":{"_header_":{"log":"","type":0,"timestamp":1455163028,"name":"person"},"person":{"age":"29","name":"jack"}}}';
var inputData6 = '{"root":{"_header_":{"log":"","type":0,"timestamp":1455163028,"name":"person"},"person":{"age":"20","name":"jack"}}}';

var outputData1 = testNode.execute(JSON.parse(inputData1));
var outputData2 = testNode.execute(JSON.parse(inputData2));
var outputData3 = testNode.execute(JSON.parse(inputData3));
var outputData4 = testNode.execute(JSON.parse(inputData4));
var outputData5 = testNode.execute(JSON.parse(inputData5));
var outputData6 = testNode.execute(JSON.parse(inputData6));

var expectData1 = '{"root":{"_header_":{"log":"","type":0,"timestamp":1455163028,"name":"median"},"median":{"age":20,"name":"jack"}}}';
var expectData2 = '{"root":{"_header_":{"log":"","type":0,"timestamp":1455163028,"name":"median"},"median":{"age":22.5,"name":"jack"}}}';
var expectData3 = '{"root":{"_header_":{"log":"","type":0,"timestamp":1455163028,"name":"median"},"median":{"age":24,"name":"jack"}}}';
var expectData4 = '{"root":{"_header_":{"log":"","type":0,"timestamp":1455163028,"name":"median"},"median":{"age":24,"name":"jack"}}}';
var expectData5 = '{"root":{"_header_":{"log":"","type":0,"timestamp":1455163028,"name":"median"},"median":{"age":24,"name":"jack"}}}';
var expectData6 = '{"root":{"_header_":{"log":"","type":0,"timestamp":1455163028,"name":"median"},"median":{"age":23,"name":"jack"}}}';


// Execute the test case
describe("Median", function () {
    it("TC1: Median passed", function (done) {
        assert.equal(JSON.stringify(outputData1), expectData1);
        done();
    });

    it("TC2: Median passed", function (done) {
        assert.equal(JSON.stringify(outputData2), expectData2);
        done();
    });

    it("TC3: Median passed", function (done) {
        assert.equal(JSON.stringify(outputData3), expectData3);
        done();
    });

    it("TC4: Median passed", function (done) {
        assert.equal(JSON.stringify(outputData4), expectData4);
        done();
    });

    it("TC5: Median passed", function (done) {
        assert.equal(JSON.stringify(outputData5), expectData5);
        done();
    });

    it("TC6: Median passed", function (done) {
        assert.equal(JSON.stringify(outputData6), expectData6);
        done();
    });
});