/*
 * log config file
 */
var config = {
    levels: {
        error: 1,
        warn: 2,
        info: 3,
        debug: 4,
    },
    colors: {
        error: 'red',
        warn: 'yellow',
        info: 'green',
        debug: 'cyan',
    },
    file: {
        level: 'error',
        file_path: 'error.log',
        json: true,
        maxsize: 5242880 //5MB
    }
    //TODO: Save the log to the kafka according to the kafka log level
    /*kafkaLevel:{
     level: 'error',
     file_path: 'error.log',
     json: true,
     maxsize: 5242880 //5MB
     },*/
};
module.exports = config;